import re
import hashlib
import random
import time
from collections import Counter, defaultdict
from typing import List, Tuple, Set, Dict, Any, Generator, Optional

## 1. clean_text

def clean_text(text: str) -> str:
    """
    Cleans raw document text by stripping HTML tags, URLs, non-ASCII characters,
    and normalizing whitespace.

    Args:
        text (str): Input raw text document.

    Returns:
        str: Cleaned and normalized text string.
    """
    # TODO: Strip unwanted markup, non-ASCII noise, and normalize spaces/newlines.
    # Remove HTML tags
    text = re.sub(r"<[^>]+>", " ", text)

    # Remove URLs
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)

    # Normalize whitespace and newlines
    text = re.sub(r"\s+", " ", text)

    # Remove leading and trailing spaces
    text = text.strip()

    return text

## 2. quality_filter

def quality_filter(
    text: str, 
    min_words: int = 50, 
    max_ratio_caps: int = 0.3, 
    max_ratio_special: float = 0.1
) -> bool:
    """
    Filters out low-quality documents based on length, capitalization ratio, and special character density.

    Args:
        text (str): Cleaned document text.
        min_words (int): Minimum required word count.
        max_ratio_caps (float): Maximum allowed ratio of ALL-CAPS words.
        max_ratio_special (float): Maximum allowed ratio of non-alphanumeric special characters.

    Returns:
        bool: True if the document meets quality criteria, False otherwise.
    """
    # TODO: Check word count thresholds and measure capitalization and special-character ratios.
    words = text.split()

    # Check minimum word count
    if len(words) < min_words:
        return False

    # Calculate ALL-CAPS word ratio
    caps_count = sum(word.isupper() for word in words)
    ratio_caps = caps_count / len(words)

    if ratio_caps > max_ratio_caps:
        return False

    # Calculate special-character ratio
    special_count = sum(
        not char.isalnum() and not char.isspace()
        for char in text
    )

    ratio_special = special_count / len(text) if text else 0

    if ratio_special > max_ratio_special:
        return False

    return True

## 3. get_shingles

def get_shingles(text: str, k: int = 5) -> Set[str]:
    """
    Extracts k-shingles (word n-grams) from a text string.

    Args:
        text (str): Input document text.
        k (int): Size of word shingle (n-gram length).

    Returns:
        Set[str]: Unique set of k-word shingles.
    """
    # TODO: Lowercase, tokenize into words, and construct word n-gram shingles.
    words = text.lower().split()

    shingles = set()

    for i in range(len(words)-k+1):
        shingle = ''.join(words[i:i + k])
        shingles.add(shingle)
    return shingles

## 4. minhash_signature

def minhash_signature(shingles: Set[str], num_hashes: int = 128) -> List[int]:
    """
    Computes MinHash signature for a set of shingles using hash function permutations.

    Args:
        shingles (Set[str]): Set of unique word shingles.
        num_hashes (int): Length of the MinHash signature vector.

    Returns:
        List[int]: MinHash signature list of length (num_hashes,).
    """
    # TODO: Generate hash permutations for each seed and compute the minimum hash value per seed.
    signature = []

    # Generate one MinHash value for each seed
    for seed in range(num_hashes):
        # Start with the largest possible value
        min_hash = float("inf")

        # Hash every shingle using the current seed
        for shingle in shingles:
            # Create a deterministic hash using the seed
            hash_value = hashlib.md5(
                f"{seed}_{shingle}".encode()
            ).hexdigest()

            # Convert hexadecimal hash to an integer
            hash_int = int(hash_value, 16)

            # Keep the smallest hash value
            if hash_int < min_hash:
                min_hash = hash_int

        # Add the minimum hash to the signature
        signature.append(min_hash)

    return signature
## 5. lsh_buckets

def lsh_buckets(signature: List[int], bands: int = 16) -> List[Tuple[int, str]]:
    """
    Divides MinHash signature into bands and maps each band to a bucket identifier using LSH.

    Args:
        signature (List[int]): MinHash signature vector of shape (num_hashes,).
        bands (int): Number of bands to divide the signature into.

    Returns:
        List[Tuple[int, str]]: List of (band_id, bucket_hash) tuples of length (bands,).
    """
    # TODO: Slice signature into bands, hash each band chunk, and map to bucket identifiers.
    bucket_ids = []

    # Calculate the number of hash values in each band
    rows_per_band = len(signature) // bands

    # Process each band
    for band_id in range(bands):
        # Slice the signature to get the current band
        start = band_id * rows_per_band
        end = start + rows_per_band
        band = signature[start:end]

        # Hash the band to create a bucket identifier
        band_hash = hashlib.md5(
            str(band).encode()
        ).hexdigest()

        # Store the band ID and bucket hash
        bucket_ids.append((band_id, band_hash))

    return bucket_ids

## 6. deduplicate

def deduplicate(
    documents: List[str], 
    threshold: float = 0.8, 
    num_hashes: int = 128, 
    bands: int = 16
) -> Tuple[List[str], int]:
    """
    Finds and removes near-duplicate documents using MinHash LSH and Jaccard similarity evaluation.

    Args:
        documents (List[str]): List of clean document strings.
        threshold (float): Jaccard similarity threshold for considering two docs as duplicates.
        num_hashes (int): Total hash functions for MinHash computation.
        bands (int): Number of bands for LSH partitioning.

    Returns:
        Tuple[List[str], int]: Tuple containing (list of deduplicated documents, count of removed duplicates).
    """
    # TODO: Build MinHash signatures and map documents into LSH band buckets.
    # TODO: Collect candidate pairs from shared buckets, verify Jaccard similarity, and prune duplicates.
     # Store LSH buckets for each document
    bucket_map = defaultdict(list)

    # TODO 1: Build MinHash signatures and map documents into LSH band buckets
    for doc_id, document in enumerate(documents):
        shingles = get_shingles(document)

        signature = minhash_signature(
            shingles,
            num_hashes=num_hashes
        )

        buckets = lsh_buckets(
            signature,
            bands=bands
        )

        # Map each bucket to the document ID
        for band_id, bucket_hash in buckets:
            bucket_map[(band_id, bucket_hash)].append(doc_id)

    # Store candidate document pairs
    candidate_pairs = set()

    # TODO 2: Collect candidate pairs from shared buckets
    for document_ids in bucket_map.values():
        for i in range(len(document_ids)):
            for j in range(i + 1, len(document_ids)):
                candidate_pairs.add(
                    (document_ids[i], document_ids[j])
                )

    # Keep track of documents that should be removed
    duplicates = set()

    # Verify candidates using Jaccard similarity
    document_shingles = [
        get_shingles(document)
        for document in documents
    ]

    for doc1, doc2 in candidate_pairs:
        shingles1 = document_shingles[doc1]
        shingles2 = document_shingles[doc2]

        intersection = len(shingles1 & shingles2)
        union = len(shingles1 | shingles2)

        jaccard = intersection / union if union else 1.0

        if jaccard >= threshold:
            duplicates.add(doc2)

    # Remove duplicate documents
    deduplicated_documents = [
        document
        for doc_id, document in enumerate(documents)
        if doc_id not in duplicates
    ]

    return deduplicated_documents, len(duplicates)


## 7. SimpleTokenizer:

class SimpleTokenizer:
    """
    A minimal Byte Pair Encoding (BPE) tokenizer implementation operating over byte sequences.
    """
    def __init__(self, vocab_size: int = 256):
        """
        Initializes tokenizer vocabulary and internal mapping structures.

        Args:
            vocab_size (int): Target vocabulary capacity.
        """
        self.vocab: Dict[int, bytes] = {i: bytes([i]) for i in range(256)}
        self.merges: Dict[Tuple[int, int], int] = {}
        self.next_id: int = 256
        self.eos_id: Optional[int] = None
        self.pad_id: int = 0

    def train_bpe(self, text: str, num_merges: int) -> None:
        """
        Iteratively finds the most frequent pair of tokens and merges them into a new token.

        Args:
            text (str): Training text corpus.
            num_merges (int): Number of BPE merge operations to execute.

        Returns:
            None
        """
        # TODO: Convert text to raw byte tokens and iteratively identify most frequent token pairs.
        # TODO: Register new merged tokens into vocabulary and replace occurrences in token stream.
        # TODO: Assign specialized End-of-Sequence (EOS) token ID.
        # Convert text to raw UTF-8 byte tokens
        tokens = list(text.encode("utf-8"))

        # Perform the requested number of BPE merge operations
        for _ in range(num_merges):

        # Count consecutive token pairs
            pair_counts = Counter(
             zip(tokens, tokens[1:])
        )

        # Stop if there are no pairs to merge
            if not pair_counts:
                break

        # Find the most frequent token pair
            best_pair, _ = pair_counts.most_common(1)[0]

        # Assign a new ID to the merged token
            new_id = self.next_id
            self.next_id += 1

        # Store the merge rule
            self.merges[best_pair] = new_id

        # Store the byte representation of the new token
            self.vocab[new_id] = (
            self.vocab[best_pair[0]] +
            self.vocab[best_pair[1]]
        )

        # Replace occurrences of the selected pair
            new_tokens = []
            i = 0

            while i < len(tokens):
                if (
                    i < len(tokens) - 1
                    and (tokens[i], tokens[i + 1]) == best_pair
            ):
                    new_tokens.append(new_id)
                    i += 2
                else:
                    new_tokens.append(tokens[i])
                    i += 1

            tokens = new_tokens

        # Assign a special ID for the End-of-Sequence token
        self.eos_id = self.next_id
        self.vocab[self.eos_id] = b""
        self.next_id += 1


    def encode(self, text: str) -> List[int]:
        """
        Encodes input text into a list of token IDs using pre-learned BPE merge rules.

        Args:
            text (str): Input text string.

        Returns:
            List[int]: Encoded list of token IDs.
        """
        # TODO: Convert input text to byte IDs and sequentially apply learned BPE merge rules.
        # Convert text to UTF-8 byte IDs
        tokens = list(text.encode("utf-8"))

        # Apply learned merge rules in their training order
        for pair, new_id in self.merges.items():

            # Store the result after applying the current merge
            new_tokens = []

            i = 0

            while i < len(tokens):

            # Check whether the current and next token form the learned pair
                if (
                    i < len(tokens) - 1
                    and (tokens[i], tokens[i + 1]) == pair
            ):
                # Replace the pair with the new merged token ID
                    new_tokens.append(new_id)

                # Skip the two tokens that were merged
                    i += 2

                else:
                # Keep the current token unchanged
                 new_tokens.append(tokens[i])

                # Move to the next token
                 i += 1

            # Update the token sequence
            tokens = new_tokens

        return tokens


    def decode(self, ids: List[int]) -> str:
        """
        Decodes a list of token IDs back into a UTF-8 string.

        Args:
            ids (List[int]): List of token IDs.

        Returns:
            str: Decoded text representation.
        """
        # TODO: Reconstruct byte sequence from token IDs, skipping special tokens, and decode to UTF-8 text.
        # Store the byte representation of each token
        byte_sequence = []

        # Process each token ID
        for token_id in ids:

        # Skip the special EOS token
            if token_id == self.eos_id:
                continue

        # Get the corresponding bytes from the vocabulary
            token_bytes = self.vocab.get(token_id)

        # Add valid token bytes to the sequence
            if token_bytes is not None:
                byte_sequence.append(token_bytes)

        # Combine all token bytes into one byte sequence
        data = b"".join(byte_sequence)

        # Decode the complete byte sequence as UTF-8
        return data.decode("utf-8")

    def vocab_size(self) -> int:
        """
        Returns the total vocabulary size including base bytes and merges.

        Returns:
            int: Total vocabulary size.
        """
        # TODO: Return total number of active entries in vocabulary.
        # Return the number of entries in the vocabulary
        return len(self.vocab)

## 8. tokenize_corpus

def tokenize_corpus(documents: List[str], tokenizer: SimpleTokenizer) -> List[int]:
    """
    Tokenizes a list of documents into a single flat stream of token IDs separated by EOS markers.

    Args:
        documents (List[str]): List of document strings.
        tokenizer (SimpleTokenizer): Trained BPE tokenizer instance.

    Returns:
        List[int]: Flat list containing combined token sequence.
    """
    # TODO: Tokenize individual documents, append EOS markers, and flatten into a continuous sequence.
    
    # Store the complete token sequence
    token_ids = []

    # Process each document separately
    for document in documents:

        # Encode the document using the trained tokenizer
        encoded = tokenizer.encode(document)

        # Add the document tokens to the continuous sequence
        token_ids.extend(encoded)

        # Add an EOS token after each document
        if tokenizer.eos_id is not None:
            token_ids.append(tokenizer.eos_id)

    return token_ids

## 9. pack_sequences

def pack_sequences(
    token_ids: List[int], 
    seq_length: int, 
    pad_id: int = 0
) -> Tuple[List[List[int]], List[List[int]]]:
    """
    Packs continuous token stream into fixed-length sequence chunks with corresponding attention masks.

    Args:
        token_ids (List[int]): Continuous flat list of token IDs.
        seq_length (int): Target length per sequence block.
        pad_id (int): Token ID used for padding incomplete trailing sequences.

    Returns:
        Tuple[List[List[int]], List[List[int]]]: Tuple of (padded_sequences, attention_masks)
            where each element has dynamic batch outer dimension and sequence shape (seq_length,).
    """
    # TODO: Chunk continuous token IDs into uniform blocks of fixed sequence length.
    # TODO: Apply padding to trailing sequence blocks and generate binary attention mask indicators.
    
    # Store the final padded sequences
    padded_sequences = []

    # Store the corresponding attention masks
    attention_masks = []

    # Process the token stream in chunks of seq_length
    for start in range(0, len(token_ids), seq_length):

        # Extract one sequence block
        sequence = token_ids[start:start + seq_length]

        # Calculate how many padding tokens are needed
        padding_length = seq_length - len(sequence)

        # Add padding if the sequence is incomplete
        if padding_length > 0:
            sequence = sequence + [pad_id] * padding_length

        # Create attention mask: 1 for real tokens, 0 for padding
        mask = [1] * (seq_length - padding_length) + [0] * padding_length

        # Store the sequence and its mask
        padded_sequences.append(sequence)
        attention_masks.append(mask)

    return padded_sequences, attention_masks

## 10. PreTrainingDataLoader:

class PreTrainingDataLoader:
    """
    Data loader providing mini-batch iteration and shuffling over packed token sequences.
    """
    def __init__(
        self, 
        sequences: List[List[int]], 
        attention_masks: List[List[int]], 
        batch_size: int, 
        shuffle: bool = True
    ):
        """
        Initializes dataloader properties.

        Args:
            sequences (List[List[int]]): Packed input sequences of shape (num_samples, seq_length).
            attention_masks (List[List[int]]): Attention masks of shape (num_samples, seq_length).
            batch_size (int): Size of individual mini-batches.
            shuffle (bool): Whether to shuffle sample indices prior to batching.
        """
        self.sequences = sequences
        self.attention_masks = attention_masks
        self.batch_size = batch_size
        self.shuffle = shuffle

    def __len__(self) -> int:
        """
        Calculates total number of batches per epoch.

        Returns:
            int: Number of available mini-batches.
        """
        # TODO: Compute total batch count accounting for ceiling division of sequence length.
        #Calculate the number of batches using ceiling divison
        return (len(self.sequences)+self.batch_size - 1 ) // self.batch_size

    def __iter__(self) -> Generator[Tuple[List[List[int]], List[List[int]]], None, None]:
        """
        Iterates over the dataset and yields mini-batches of sequences and attention masks.

        Returns:
            Generator[Tuple[List[List[int]], List[List[int]]], None, None]: Batch generator yielding 
            (batch_sequences, batch_attention_masks) where each tensor component has shape (batch_size, seq_length).
        """
        # TODO: Shuffle document indices conditionally, iterate in mini-batch strides, and yield batch slices.

        # Create sequence indices
        indices = list(range(len(self.sequences)))

        # Shuffle indices if enabled
        if self.shuffle:
            random.shuffle(indices)

        # Iterate over indices in mini-batch strides
        for start in range(0, len(indices), self.batch_size):

        # Select indices for the current batch
            batch_indices = indices[start:start + self.batch_size]

        # Get sequences and attention masks for the current batch
            batch_sequences = [
                self.sequences[i]
                for i in batch_indices
        ]

            batch_attention_masks = [
                self.attention_masks[i]
                for i in batch_indices
        ]

        # Yield the current batch
            yield batch_sequences, batch_attention_masks
        
    
        

## 11. compute_statistics

def compute_statistics(
    documents: List[str], 
    token_ids: List[int], 
    sequences: List[List[int]], 
    tokenizer_vocab_size: int
) -> Dict[str, Any]:
    """
    Computes overall corpus, vocabulary, compression, and sequence padding efficiency metrics.

    Args:
        documents (List[str]): Corpus of cleaned documents.
        token_ids (List[int]): Continuous flat list of token IDs.
        sequences (List[List[int]]): Packed token sequences.
        tokenizer_vocab_size (int): Size of the tokenizer vocabulary.

    Returns:
        Dict[str, Any]: Dictionary containing pre-training dataset analytical statistics.
    """
    # TODO: Measure total corpus dimensions, compute character-to-token compression, and track document lengths.
    # TODO: Calculate top token frequencies, sequence padding efficiency ratios, and vocabulary utilization.
    # Calculate total corpus dimensions
    total_documents = len(documents)
    total_characters = sum(len(document) for document in documents)
    total_tokens = len(token_ids)

    # Calculate unique tokens and vocabulary utilization
    unique_tokens = len(set(token_ids))
    vocab_utilization = (
        unique_tokens / tokenizer_vocab_size
        if tokenizer_vocab_size
        else 0.0
    )

    # Calculate character-to-token compression ratio
    compression_ratio = (
        total_characters / total_tokens
        if total_tokens
        else 0.0
    )

    # Calculate average document length in words
    document_lengths = [
        len(document.split())
        for document in documents
    ]

    avg_doc_length_words = (
        sum(document_lengths) / len(document_lengths)
        if document_lengths
        else 0.0
    )

    # Calculate top token frequencies
    token_counts = Counter(token_ids)
    top_token_frequencies = token_counts.most_common(10)

    # Calculate sequence padding efficiency
    num_sequences = len(sequences)

    if sequences:
        total_sequence_capacity = sum(len(sequence) for sequence in sequences)
        total_non_padding_tokens = sum(
            token_id != 0
            for sequence in sequences
            for token_id in sequence
        )

        sequence_utilization = (
            total_non_padding_tokens / total_sequence_capacity
            if total_sequence_capacity
            else 0.0
        )
    else:
        sequence_utilization = 0.0

    return {
        "total_documents": total_documents,
        "total_characters": total_characters,
        "total_tokens": total_tokens,
        "unique_tokens": unique_tokens,
        "vocab_utilization": vocab_utilization,
        "compression_ratio": compression_ratio,
        "avg_doc_length_words": avg_doc_length_words,
        "top_token_frequencies": top_token_frequencies,
        "num_sequences": num_sequences,
        "sequence_utilization": sequence_utilization,
    }



# [KEEP_IMPLEMENTATION]

## 12. generate_sample_corpus

def generate_sample_corpus() -> List[str]:
    """
    Generates a pre-defined synthetic corpus containing standard, duplicate, HTML, and spam documents.

    Returns:
        List[str]: List of raw document strings.
    """
    base_docs = [
        "Machine learning is a subset of artificial intelligence that provides systems the ability "
        "to automatically learn and improve from experience without being explicitly programmed. "
        "Machine learning focuses on the development of computer programs that can access data and "
        "use it to learn for themselves. The process of learning begins with observations or data, "
        "such as examples, direct experience, or instruction, in order to look for patterns in data "
        "and make better decisions in the future based on the examples that we provide.",

        "Deep learning is part of a broader family of machine learning methods based on artificial "
        "neural networks with representation learning. Learning can be supervised, semi-supervised "
        "or unsupervised. Deep learning architectures such as deep neural networks, recurrent neural "
        "networks, convolutional neural networks and transformers have been applied to fields "
        "including natural language processing, speech recognition, computer vision, and many other tasks.",

        "Natural language processing is a subfield of linguistics, computer science, and artificial "
        "intelligence concerned with the interactions between computers and human language, in "
        "particular how to program computers to process and analyze large amounts of natural language "
        "data. The result is a computer capable of understanding the contents of documents, including "
        "the contextual nuances of the language within them.",

        "Transformers are a type of neural network architecture that has become the dominant approach "
        "for natural language processing tasks. The key innovation is the self-attention mechanism, "
        "which allows the model to weigh the importance of different parts of the input when producing "
        "each part of the output. This enables transformers to capture long-range dependencies in text "
        "much more effectively than previous recurrent approaches.",

        "The attention mechanism in neural networks allows the model to focus on relevant parts of "
        "the input sequence when generating each element of the output. In the transformer architecture, "
        "multi-head attention computes attention in parallel across multiple representation subspaces, "
        "enabling the model to jointly attend to information from different representation subspaces "
        "at different positions in the sequence.",

        "Reinforcement learning is an area of machine learning concerned with how intelligent agents "
        "ought to take actions in an environment in order to maximize the notion of cumulative reward. "
        "Reinforcement learning is one of three basic machine learning paradigms, alongside supervised "
        "learning and unsupervised learning. It differs from supervised learning in that correct input "
        "and output pairs need not be presented.",

        "Computer vision is an interdisciplinary scientific field that deals with how computers can "
        "gain high-level understanding from digital images or videos. From the perspective of "
        "engineering, it seeks to understand and automate tasks that the human visual system can do. "
        "Computer vision tasks include methods for acquiring, processing, analyzing and understanding "
        "digital images, and extraction of high-dimensional data from the real world.",

        "Convolutional neural networks are a class of deep learning architecture commonly applied to "
        "analyze visual imagery. They use a variation of multilayer perceptrons designed to require "
        "minimal preprocessing. They are also known as shift invariant or space invariant artificial "
        "neural networks based on their shared-weights architecture and translation invariance "
        "characteristics. Convolutional networks were inspired by biological processes.",

        "Generative adversarial networks consist of two neural networks that contest with each other "
        "in the form of a zero-sum game, where one agent gain is another agent loss. Given a training "
        "set, this technique learns to generate new data with the same statistics as the training set. "
        "For example, a generative adversarial network trained on photographs can generate new "
        "photographs that look authentic to human observers.",

        "Transfer learning is a machine learning method where a model developed for a task is reused "
        "as the starting point for a model on a second task. It is a popular approach in deep learning "
        "where pre-trained models are used as the starting point on computer vision and natural language "
        "processing tasks given the vast compute and time resources required to develop neural network "
        "models on these problems and the large improvements they provide.",
    ]

    near_dup_1 = (
        "Machine learning is a subset of artificial intelligence that provides systems the ability "
        "to automatically learn and improve from experience. Machine learning focuses on developing "
        "computer programs that can access data and use it to learn for themselves. The learning "
        "process begins with observations or data, such as examples or direct experience, in order "
        "to look for patterns and make better decisions based on the examples provided."
    )

    near_dup_2 = (
        "Deep learning is part of a broader family of machine learning methods based on artificial "
        "neural networks with representation learning. Learning can be supervised, semi-supervised "
        "or unsupervised. Deep learning architectures such as deep neural networks, recurrent neural "
        "networks, convolutional neural networks and transformers have been applied to fields "
        "including natural language processing, speech recognition, computer vision, and many other tasks."
    )

    short_doc = "This is too short to be useful."

    html_doc = (
        "<html><body><h1>Title</h1><p>Machine learning is transforming how we build software. "
        "Deep neural networks can learn complex patterns from data. The transformer architecture "
        "has become the dominant approach for language tasks. Self-attention allows models to capture "
        "long-range dependencies. Pre-training on large corpora produces strong foundation models. "
        "Fine-tuning adapts these models to specific tasks with minimal additional data.</p></body></html>"
    )

    spam_doc = "BUY NOW CLICK HERE FREE MONEY GUARANTEED RESULTS " * 20

    docs = base_docs + [near_dup_1, near_dup_2, short_doc, html_doc, spam_doc]
    return docs


# [KEEP_IMPLEMENTATION]

## 13. run_pipeline

def run_pipeline():
    """
    Executes end-to-end data processing pipeline for pre-training dataset preparation.
    """
    print("=" * 60)
    print("Data Pipeline for Pre-Training")
    print("=" * 60)

    raw_docs = generate_sample_corpus()
    print(f"\nRaw documents: {len(raw_docs)}")

    print("\n--- Stage 1: Cleaning ---")
    cleaned_docs = [clean_text(doc) for doc in raw_docs]
    print(f"After HTML stripping: {len(cleaned_docs)} documents")

    print("\n--- Stage 2: Quality Filtering ---")
    filtered_docs = [doc for doc in cleaned_docs if quality_filter(doc)]
    removed_quality = len(cleaned_docs) - len(filtered_docs)
    print(f"Removed {removed_quality} low-quality documents")
    print(f"Remaining: {len(filtered_docs)} documents")

    print("\n--- Stage 3: Deduplication (MinHash + LSH) ---")
    start = time.time()
    deduped_docs, num_removed = deduplicate(filtered_docs, threshold=0.8)
    dedup_time = time.time() - start
    print(f"Removed {num_removed} near-duplicates in {dedup_time:.2f}s")
    print(f"Remaining: {len(deduped_docs)} documents")

    print("\n--- Stage 4: Tokenization ---")
    all_text = " ".join(deduped_docs)
    tokenizer = SimpleTokenizer()
    start = time.time()
    tokenizer.train_bpe(all_text, num_merges=100)
    train_time = time.time() - start
    print(f"Trained tokenizer with {tokenizer.vocab_size()} tokens in {train_time:.2f}s")

    start = time.time()
    token_ids = tokenize_corpus(deduped_docs, tokenizer)
    tok_time = time.time() - start
    print(f"Tokenized {len(token_ids):,} tokens in {tok_time:.2f}s ({len(token_ids)/max(tok_time, 0.001):,.0f} tokens/sec)")

    print("\n--- Stage 5: Sequence Packing ---")
    seq_length = 128
    sequences, masks = pack_sequences(token_ids, seq_length, pad_id=0)
    print(f"Packed into {len(sequences)} sequences of length {seq_length}")

    print("\n--- Stage 6: DataLoader ---")
    batch_size = 4
    loader = PreTrainingDataLoader(sequences, masks, batch_size)
    print(f"DataLoader: {len(loader)} batches of size {batch_size}")

    batch_count = 0
    total_tokens_served = 0
    for batch_seqs, batch_masks in loader:
        batch_count += 1
        total_tokens_served += sum(sum(m) for m in batch_masks)
        if batch_count <= 2:
            print(f"\n  Batch {batch_count}:")
            print(f"    Sequences: {len(batch_seqs)}")
            print(f"    First seq (first 20 tokens): {batch_seqs[0][:20]}...")
            print(f"    First mask (first 20): {batch_masks[0][:20]}...")
    print(f"\n  Total batches served: {batch_count}")
    print(f"  Total non-padding tokens served: {total_tokens_served:,}")

    print("\n--- Dataset Statistics ---")
    stats = compute_statistics(deduped_docs, token_ids, sequences, tokenizer.vocab_size())
    print(f"  Documents:           {stats['total_documents']}")
    print(f"  Total characters:    {stats['total_characters']:,}")
    print(f"  Total tokens:        {stats['total_tokens']:,}")
    print(f"  Unique tokens:       {stats['unique_tokens']}")
    print(f"  Vocab utilization:  {stats['vocab_utilization']:.1%}")
    print(f"  Compression ratio:  {stats['compression_ratio']:.2f} chars/token")
    print(f"  Avg doc length:     {stats['avg_doc_length_words']:.0f} words")
    print(f"  Num sequences:      {stats['num_sequences']}")
    print(f"  Seq utilization:    {stats['sequence_utilization']:.1%}")

    print("\n--- Pipeline Summary ---")
    print(f"  Raw documents:       {len(raw_docs)}")
    print(f"  After cleaning:      {len(cleaned_docs)}")
    print(f"  After quality filter: {len(filtered_docs)} (-{removed_quality})")
    print(f"  After dedup:         {len(deduped_docs)} (-{num_removed})")
    print(f"  Final tokens:        {len(token_ids):,}")
    print(f"  Training sequences:  {len(sequences)}")
    print(f"  Training batches:    {len(loader)}")


# ===== UNIT TESTS =====

## 14. test_clean_text

def test_clean_text():
    sample = "<html><body>Hello    World! http://example.com</body></html>"
    cleaned = clean_text(sample)
    assert isinstance(cleaned, str), "Output must be a string."
    assert "<html>" not in cleaned, "HTML tags were not removed."
    assert "http" not in cleaned, "URLs were not stripped."
    assert "  " not in cleaned, "Multiple spaces were not collapsed."
    
    # Edge case: Empty input string
    assert clean_text("") == "", "Edge case failed: Empty string must return an empty string."

## 15. test_quality_filter

def test_quality_filter():
    good_text = " ".join(["word"] * 60)
    bad_text_short = "short text"
    bad_text_caps = " ".join(["WORD"] * 60)
    
    assert quality_filter(good_text) is True, "Valid document failed quality filter."
    assert quality_filter(bad_text_short) is False, "Short document incorrectly passed quality filter."
    assert quality_filter(bad_text_caps) is False, "Overly-capitalized document passed quality filter."
    
    # Edge case: Boundary word count
    exact_words = " ".join(["word"] * 50)
    assert quality_filter(exact_words, min_words=50) is True, "Edge case failed: Exact min_words boundary missed."

## 16. test_get_shingles

def test_get_shingles():
    text = "the quick brown fox jumps over the lazy dog"
    shingles = get_shingles(text, k=3)
    assert isinstance(shingles, set), "Output should be a set."
    assert len(shingles) == 7, "Shingle extraction length mismatch."
    
    # Edge case: Text shorter than k
    short_text = "quick brown"
    assert get_shingles(short_text, k=5) == set(), "Edge case failed: Text shorter than k must return an empty set."

## 17. test_minhash_signature

def test_minhash_signature():
    shingles = {"quick brown fox", "brown fox jumps"}
    sig = minhash_signature(shingles, num_hashes=32)
    assert isinstance(sig, list), "MinHash signature must be a list."
    assert len(sig) == 32, "Signature length must match requested num_hashes."
    
    # Edge case: Empty shingle set
    empty_sig = minhash_signature(set(), num_hashes=16)
    assert len(empty_sig) == 16, "Edge case failed: MinHash length mismatched for empty shingles."
    assert all(val == 0 for val in empty_sig), "Edge case failed: Empty shingle signature must default to 0s."

## 18. test_lsh_buckets

def test_lsh_buckets():
    random.seed(42)
    sig = [random.randint(0, 1000) for _ in range(128)]
    buckets = lsh_buckets(sig, bands=16)
    assert isinstance(buckets, list), "Output must be a list."
    assert len(buckets) == 16, "Number of generated buckets must match bands count."
    assert len(buckets[0]) == 2, "Each bucket element must be a (band_id, bucket_hash) tuple."

## 19. test_deduplicate

def test_deduplicate():
    docs = [
        "Natural language processing is a subfield of linguistics and computer science.",
        "Natural language processing is a subfield of linguistics and computer science.",
        "Computer vision allows computers to derive meaningful information from digital images."
    ]
    deduped, removed = deduplicate(docs, threshold=0.8)
    assert isinstance(deduped, list), "Deduplicated docs must be returned as a list."
    assert len(deduped) == 2, "Duplicate document was not removed."
    assert removed == 1, "Removed duplicate count is incorrect."
    
    # Edge case: Single document input
    single_doc = ["Single document text."]
    d_out, r_out = deduplicate(single_doc)
    assert len(d_out) == 1 and r_out == 0, "Edge case failed: Single document should yield no duplicates."

## 20. test_simple_tokenizer

def test_simple_tokenizer():
    tok = SimpleTokenizer()
    text = "hello world hello world"
    tok.train_bpe(text, num_merges=2)
    
    encoded = tok.encode("hello world")
    assert isinstance(encoded, list), "Encoded tokens must be a list of IDs."
    assert len(encoded) > 0, "Encoded sequence should not be empty."
    
    decoded = tok.decode(encoded)
    assert isinstance(decoded, str), "Decoded output must be a string."
    assert decoded == "hello world", "Decoded text does not match original."
    
    # Edge case: Out of vocabulary / raw unseen bytes
    unseen = tok.encode("xyz123")
    assert tok.decode(unseen) == "xyz123", "Edge case failed: Unseen characters were not decoded back accurately."

## 21. test_tokenize_corpus

def test_tokenize_corpus():
    tok = SimpleTokenizer()
    tok.train_bpe("test document", num_merges=1)
    docs = ["test", "document"]
    tokens = tokenize_corpus(docs, tok)
    
    assert isinstance(tokens, list), "Corpus tokens must be a list."
    assert tokens.count(tok.eos_id) == 2, "Corpus token sequence must include one EOS token per document."

## 22. test_pack_sequences

def test_pack_sequences():
    tokens = list(range(10))
    seqs, masks = pack_sequences(tokens, seq_length=4, pad_id=0)
    
    assert len(seqs) == 3, "Packed sequence count mismatch."
    assert len(seqs[0]) == 4, "Sequence block length mismatch."
    assert seqs[2] == [8, 9, 0, 0], "Padding incorrect on last sequence block."
    assert masks[2] == [1, 1, 0, 0], "Attention mask incorrect on padded sequence block."
    
    # Edge case: Empty token input
    e_seqs, e_masks = pack_sequences([], seq_length=4)
    assert len(e_seqs) == 0 and len(e_masks) == 0, "Edge case failed: Empty tokens should return empty lists."

## 23. test_pre_training_data_loader

def test_pre_training_data_loader():
    seqs = [[1, 2, 3, 4] for _ in range(10)]
    masks = [[1, 1, 1, 1] for _ in range(10)]
    loader = PreTrainingDataLoader(seqs, masks, batch_size=4, shuffle=False)
    
    assert len(loader) == 3, "DataLoader batch count mismatch."
    
    batches = list(loader)
    first_b_seqs, first_b_masks = batches[0]
    assert len(first_b_seqs) == 4, "Batch size mismatch."
    assert len(first_b_masks) == 4, "Attention mask batch size mismatch."
    
    # Edge case: Batch size greater than dataset size
    loader_large = PreTrainingDataLoader(seqs[:2], masks[:2], batch_size=8)
    large_batches = list(loader_large)
    assert len(large_batches) == 1, "Edge case failed: Oversized batch should return exactly 1 mini-batch."
    assert len(large_batches[0][0]) == 2, "Edge case failed: Single batch size should match total available samples."

## 24. test_compute_statistics

def test_compute_statistics():
    docs = ["one two three", "four five"]
    token_ids = [1, 2, 3, 4, 5]
    sequences = [[1, 2, 3], [4, 5, 0]]
    
    stats = compute_statistics(docs, token_ids, sequences, tokenizer_vocab_size=256)
    assert isinstance(stats, dict), "Statistics output must be a dictionary."
    assert stats["total_documents"] == 2, "Stat mismatch: Total documents."
    assert stats["total_tokens"] == 5, "Stat mismatch: Total tokens."
    assert "compression_ratio" in stats, "Missing metric: compression_ratio."
    assert 0.0 <= stats["sequence_utilization"] <= 1.0, "Sequence utilization ratio out of valid bounds [0, 1]."

## 25. Main

if __name__ == "__main__":
    run_pipeline()

# Persian Mini-GPT: A From-Scratch Language Model for Medical Reviews

Authors: Amin Bazyar · Mahdieh Gholedarzadeh 

A complete, from-scratch implementation of a GPT-style language model — including a
hand-built Byte Pair Encoding (BPE) tokenizer and a Transformer-based mini GPT — trained
on real Persian-language patient reviews of doctors.

No pretrained tokenizers, no pretrained weights: the tokenizer, the model architecture,
and the training loop are all implemented from scratch in PyTorch and plain Python.

---

##  Overview

This project explores how a small GPT-style language model can be trained end-to-end on
a real-world, low-resource-language dataset (Persian) without relying on any existing
tokenizer or pretrained model. It was built as a hands-on deep dive into the core
mechanics of modern language models:

- How raw text becomes tokens (Byte Pair Encoding, implemented manually)
- How a Transformer decoder predicts the next token
- How a full data pipeline connects noisy real-world text to a trainable model

The dataset consists of real patient comments about doctors, scraped and cleaned as part
of a separate NLP pipeline, then repurposed here as raw text for language modeling.

---

##  Features

- Custom BPE tokenizer — built from scratch (no sentencepiece, no HuggingFace
  tokenizers), including merge-rule training, encode/decode, and special tokens
- Mini GPT architecture — token embeddings, multi-head self-attention, causal
  masking, feed-forward blocks, and a training loop, all implemented manually in PyTorch
- Full Persian NLP data pipeline — cleaning, quality filtering, and tokenization of
  real, noisy user-generated text
- Trained on real data — not toy sentences: 60K+ real Persian medical reviews
- Bilingual documentation — every notebook is documented in both English and Persian

---

##  Project Structure

mini-gpt-project/
├── configs/                  # (reserved for model/training configs)
├── data/
│   ├── raw/                  # Original comments_raw_canonical.csv
│   └── processed/            # Tokenized data (token_ids.json) + saved tokenizer (tokenizer.pkl)
├── notebooks/
│   ├── 01_tokenizer1_test.ipynb      # Simple character/BPE tokenizer prototype
│   ├── 02_tokenizer2_test.ipynb      # Production byte-level BPE tokenizer (multi-language tested)
│   ├── 03_data_pipeline_test.ipynb   # Data pipeline reference implementation (toy data)
│   ├── 04_mini_gpt_test.ipynb        # Mini GPT model + training + text generation
│   └── 05_data_pipeline_persian.ipynb # Real pipeline run on the Persian dataset
├── outputs/                  # (reserved for generated artifacts)
├── scripts/
│   ├── run_persian_data_pipeline.py       # Standalone: clean, tokenize & save the Persian dataset
│   └── run_persian_mini_gpt_training.py   # Standalone: train Mini GPT on the tokenized Persian data
├── src/
│   ├── data/
│   │   └── data_pipeline.py   # Reusable cleaning/tokenizer/pipeline building blocks
│   ├── models/
│   │   └── mini_gpt.py        # Reusable Mini GPT model classes
│   └── tokenization/
│       ├── tokenizer1.py      # Simple BPE tokenizer prototype
│       └── tokenizer2.py      # Production byte-level BPE tokenizer
├── tests/                     # Unit tests
├── requirements.txt
├── LICENSE
└── README.md
---

##  Setup

git clone <repo-url>
cd mini-gpt-project

python3 -m venv .venv
source .venv/bin/activate

pip install -r requirements.txt
Requirements: torch, regex, tiktoken, pandas

---

##  Usage

Option A — step through the notebooks (recommended for learning/review):

1. **01_tokenizer1_test.ipynb** / **02_tokenizer2_test.ipynb** — build and unit-test
   the BPE tokenizers on toy text
   2. **05_data_pipeline_persian.ipynb** — load data/raw/comments_raw_canonical.csv,
   clean and filter the real Persian comments, train the BPE tokenizer on them, and save
   both the tokenized corpus (token_ids.json) and the tokenizer object (tokenizer.pkl)
   to data/processed/
3. **04_mini_gpt_test.ipynb** — load the saved tokenizer and tokenized data, train the
   Mini GPT model (train_mini_gpt_custom), and generate samplOption B — run the standalone scripts directly:ectly:**

# 1. Clean, tokenize, and save the Persian dataset
python scripts/run_persian_data_pipeline.py

# 2. Train Mini GPT on the tokenized data and generate sample text
python scripts/run_persian_mini_gpt_training.py
---

##  Results

| Metric | Value |
|---|---|
| Raw comments | 66,465 |
| Comments after cleaning & quality filtering | 63,491 |
| Tokenizer vocabulary size | 1,057 |
| Total training tokens | 819,470 |
| Training steps | 1,500 |
| Loss (start → end) | 6.99 → ~4.0Sample generationration** (prompt: سلام / "hello"):

سلام برای خرد نخفیدبسیار دکتربسیار عالیداماالی .عفونت و عالی بودنسلامعالی بود.
تشخیص و درمانش سفا و مرفیبحر نتیجه عالی برام مراجعه شد.ف
The output is not yet fully fluent (expected for a mini model trained for only 1,500
steps), but it correctly reproduces vocabulary specific to the medical-review domain
(دکتر / doctor, تشخیص / diagnosis, درمان / treatment, عالی / excellent) — confirming that
the tokenizer, data pipeline, and model are correctly connected end-to-end.

> Increasing num_steps to ~5,000 is expected to bring the loss down toward ~3.0–3.5
> and noticeably improve fluency, at roughly 3x the training time.

---

##  Notes

### tiktoken network access issue

tiktoken normally downloads its encoding files (e.g. cl100k_base) from OpenAI's
servers on first use. Due to network restrictions in some regions, this direct download
canWorkaround used in this project:oject:**

1. The required encoding file was downloaded manually from a Microsoft-hosted mirror.
2. A local cache folder was created (~/tiktoken_cache).
3. The downloaded file was placed in that folder under the hash-based filename tiktoken
   expects for its cache lookup.
4. The cache directory is set *before* importing tiktoken:

import os
os.environ["TIKTOKEN_CACHE_DIR"] = os.path.expanduser("~/tiktoken_cache")

import tiktoken
With this in place, the project runs fully offline with no network dependency at runtime.

---

##  Tech Stack

- Python 3.11
- PyTorch
- pandas
- regex
- tiktoken
- Jupyter Notebook

---

##  Authors

- Amin Bazyar 
- Mahdieh Gholedarzadeh 

---

##  License

See [LICENSE](./LICENSE) for details.